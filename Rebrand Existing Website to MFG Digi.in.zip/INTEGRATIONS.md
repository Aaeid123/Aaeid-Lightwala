# AK Innovexa Integration and Deployment Notes

## Current implementation

The website is a React and TypeScript single-page application built with Vite. The interactive ecosystem, AI Lab, workflow comparison, portfolio concepts, pricing, FAQs, and dashboard are frontend demonstrations.

The enquiry form validates required fields in the browser and opens a pre-filled WhatsApp message for the visitor to review. It does not store data or claim that a submission was received.

## Production integrations still required

Connect a secure backend before enabling any of the following:

- Persistent enquiry storage or CRM creation
- Transactional email delivery
- Consultation calendar booking
- Live AI or retrieval-augmented generation
- Invoice uploads and OCR processing
- WhatsApp Business Platform messaging
- SMS, OTP, RCS, voice, or email automation
- User accounts, client dashboards, or subscriptions
- Analytics and server-side conversion events

Server endpoints should include schema validation, consent records, rate limiting, spam protection, authentication where applicable, safe file restrictions, audit logging, and privacy-conscious retention rules.

## Suggested environment variables

Add only the variables required by the selected providers, and keep them server-side:

```text
DATABASE_URL
CRM_API_KEY
EMAIL_PROVIDER_API_KEY
WHATSAPP_ACCESS_TOKEN
WHATSAPP_PHONE_NUMBER_ID
AI_PROVIDER_API_KEY
OCR_PROVIDER_API_KEY
ANALYTICS_ID
```

Provider names and exact variables should be confirmed during implementation. Never expose private keys in Vite-prefixed frontend environment variables.

## Communication providers

WhatsApp, SMS, OTP, RCS, voice, and email depend on supported providers, account approval, regional availability, opt-in rules, approved templates, and provider fees. A custom application can orchestrate these services but cannot bypass their platform policies.

## Local verification

```bash
pnpm install
pnpm build
```

The Figma Make development server is managed automatically. Do not start an additional development server inside Make.

## Deployment

Deploy the generated Vite application to a static host that supports SPA fallback. Configure the production domain, HTTPS, cache headers, security headers, canonical URL, sitemap hostname, and analytics consent before launch.

If the production domain changes from `akdeveloper.in`, update `index.html`, `public/sitemap.xml`, and `public/robots.txt`.
