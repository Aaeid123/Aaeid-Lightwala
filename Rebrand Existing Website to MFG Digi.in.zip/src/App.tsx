import { FormEvent, ReactNode, useState } from "react"

const PHONE = "917874226912"
const EMAIL = "aaeidlghtwala@gmail.com"

type IconName =
  | "arrow"
  | "automation"
  | "chart"
  | "check"
  | "cloud"
  | "code"
  | "commerce"
  | "data"
  | "design"
  | "menu"
  | "mobile"
  | "search"
  | "spark"
  | "web"
  | "whatsapp"
  | "x"

const serviceGroups = [
  {
    icon: "web" as IconName,
    title: "Website Development",
    description: "Fast, credible websites designed around your audience and business goals.",
    deliverables: ["Business & corporate sites", "Landing pages & redesigns", "SEO-ready architecture"],
    useCase: "For businesses that need a stronger, easier-to-manage digital presence.",
  },
  {
    icon: "commerce" as IconName,
    title: "E-commerce Development",
    description: "Customer-friendly online stores with practical catalogue and order workflows.",
    deliverables: ["Product catalogues", "Checkout & payment setup", "Inventory integrations"],
    useCase: "For retailers and suppliers ready to sell or accept orders online.",
  },
  {
    icon: "code" as IconName,
    title: "Custom Software",
    description: "Purpose-built applications that fit the way your team actually works.",
    deliverables: ["Admin dashboards", "CRM & lead management", "Role-based business tools"],
    useCase: "For teams outgrowing spreadsheets or disconnected off-the-shelf tools.",
  },
  {
    icon: "spark" as IconName,
    title: "AI & Machine Learning",
    description: "Grounded AI tools that assist customers and teams with appropriate oversight.",
    deliverables: ["Knowledge assistants", "OCR & document extraction", "AI API integrations"],
    useCase: "For suitable processes where reliable data and human review are available.",
  },
  {
    icon: "automation" as IconName,
    title: "Business Automation",
    description: "Connected workflows that reduce repetitive entry, delays, and manual handoffs.",
    deliverables: ["Lead routing", "Form-to-database flows", "Notifications & API integrations"],
    useCase: "For repeatable processes spread across forms, inboxes, and business systems.",
  },
  {
    icon: "chart" as IconName,
    title: "Digital Marketing",
    description: "Search, content, campaigns, and measurement aligned to meaningful enquiries.",
    deliverables: ["SEO & local visibility", "Meta Ads setup", "Analytics & conversion tracking"],
    useCase: "For businesses seeking measurable visibility without unsupported promises.",
  },
  {
    icon: "whatsapp" as IconName,
    title: "WhatsApp & Communication",
    description: "Approved customer communication workflows connected to your business process.",
    deliverables: ["Enquiry automation", "Reminders & support routing", "CRM-connected conversations"],
    useCase: "For opted-in communication through supported WhatsApp Business integrations.",
  },
  {
    icon: "design" as IconName,
    title: "UI/UX & Product Design",
    description: "Clear, accessible interfaces that make digital products easier to understand.",
    deliverables: ["Wireframes & prototypes", "SaaS dashboard design", "Design systems"],
    useCase: "For products that need a clearer journey before development begins.",
  },
  {
    icon: "mobile" as IconName,
    title: "Mobile Applications",
    description: "Cross-platform and native-ready mobile experiences connected to secure APIs.",
    deliverables: ["Customer portals", "Business management apps", "API-connected applications"],
    useCase: "For mobile workflows that require project-specific design and development.",
  },
  {
    icon: "data" as IconName,
    title: "Data & Business Intelligence",
    description: "Useful reporting systems that turn business data into understandable decisions.",
    deliverables: ["Power BI dashboards", "Automated reports", "KPI monitoring"],
    useCase: "For teams with data in multiple systems and limited reporting visibility.",
  },
  {
    icon: "cloud" as IconName,
    title: "Cloud & Technical Support",
    description: "Practical infrastructure, integration, performance, and maintenance support.",
    deliverables: ["Cloud deployment", "Database & hosting setup", "Monitoring & optimization"],
    useCase: "For digital systems that need stable deployment and ongoing technical care.",
  },
]

const automationCases = [
  ["AI Customer Support", "Answer approved knowledge-base questions and route complex requests to people."],
  ["Lead Management", "Capture enquiries, organize them in a CRM, and alert the relevant sales team."],
  ["OCR Processing", "Extract suitable document data with validation before important records are saved."],
  ["Business Analytics", "Bring sales, marketing, and operational information into useful reports."],
  ["WhatsApp Automation", "Support eligible notifications and routing through approved integrations."],
  ["Connected Workflows", "Link business tools to reduce repetitive entry and manual handoffs."],
]

const ecosystemNodes = [
  {
    icon: "web" as IconName,
    title: "Web & commerce",
    problem: "Disconnected customer journeys make it harder to discover, evaluate, and enquire.",
    connects: "CRM, product data, payments, analytics",
    deliverables: "Business websites, stores, portals, landing pages",
  },
  {
    icon: "data" as IconName,
    title: "CRM",
    problem: "Enquiries are scattered across inboxes, spreadsheets, and individual team members.",
    connects: "Website forms, WhatsApp, email, sales dashboards",
    deliverables: "Lead pipelines, assignment rules, follow-up visibility",
  },
  {
    icon: "spark" as IconName,
    title: "AI assistants",
    problem: "Teams repeatedly answer the same questions or search across approved documents.",
    connects: "Knowledge bases, websites, help desks, internal tools",
    deliverables: "Grounded assistants, search, document intelligence",
  },
  {
    icon: "whatsapp" as IconName,
    title: "Messaging",
    problem: "Customer communication is slow, inconsistent, or difficult to track.",
    connects: "Official providers, CRM, support queues, notifications",
    deliverables: "Opt-in messaging, routing, reminders, status updates",
  },
  {
    icon: "code" as IconName,
    title: "Business apps",
    problem: "Generic tools do not reflect the way a specialist operation needs to work.",
    connects: "APIs, databases, users, operational systems",
    deliverables: "Admin tools, portals, CRM and ERP modules",
  },
  {
    icon: "chart" as IconName,
    title: "Analytics",
    problem: "Important decisions rely on delayed or inconsistent reporting.",
    connects: "Sales, marketing, finance, operations",
    deliverables: "Power BI, KPI dashboards, scheduled reports",
  },
  {
    icon: "search" as IconName,
    title: "Growth",
    problem: "Marketing activity is not connected to useful conversion signals.",
    connects: "SEO, paid media, landing pages, CRM",
    deliverables: "Campaign systems, tracking, content and optimization",
  },
  {
    icon: "automation" as IconName,
    title: "Automation",
    problem: "Manual handoffs create repeated entry, delays, and limited accountability.",
    connects: "Webhooks, n8n, business rules, notifications",
    deliverables: "Validated workflows, approvals, synchronization",
  },
]

const labDemos = [
  {
    title: "AI Business Assistant",
    icon: "spark" as IconName,
    preview: "Ask a sample business knowledge base about products, policies, or processes.",
    limitation: "Preview only — no live model or private business documents are connected.",
    output: ["Grounded sample answers", "Source-aware response pattern", "Human escalation path"],
  },
  {
    title: "Invoice Intelligence",
    icon: "search" as IconName,
    preview: "See how suitable invoices can be mapped into structured business fields.",
    limitation: "No file is uploaded or processed in this frontend demonstration.",
    output: ["Invoice INV-2048", "Vendor: Sample Industries", "Total: ₹48,720"],
  },
  {
    title: "Automation Simulator",
    icon: "automation" as IconName,
    preview: "Explore a trigger, validation, processing, action, and reporting sequence.",
    limitation: "Illustrative workflow; production requires authenticated APIs and business rules.",
    output: ["Trigger received", "Consent validated", "CRM task created"],
  },
  {
    title: "Sales Analytics",
    icon: "chart" as IconName,
    preview: "Explore clearly labelled sample trends, category mix, and dashboard design.",
    limitation: "Uses demonstration data and does not forecast real business performance.",
    output: ["Monthly sample trend", "Category comparison", "Review-ready insight"],
  },
  {
    title: "Communication Flow",
    icon: "whatsapp" as IconName,
    preview: "Follow an opted-in enquiry from a web form to CRM and approved follow-up.",
    limitation: "No message is sent; official provider setup and templates are required.",
    output: ["Opt-in checked", "Lead assigned", "Permitted follow-up queued"],
  },
]

const transformations = [
  {
    title: "Lead management",
    before: ["Manual enquiry", "Spreadsheet", "Repeated entry", "Delayed follow-up", "Separate reports"],
    after: ["Website enquiry", "Validated lead", "CRM assignment", "Approved follow-up", "Shared dashboard"],
  },
  {
    title: "Invoice processing",
    before: ["Email attachment", "Manual reading", "Copy fields", "Recheck totals", "File separately"],
    after: ["Secure intake", "OCR extraction", "Field validation", "Human approval", "System update"],
  },
  {
    title: "Customer support",
    before: ["Repeated question", "Search documents", "Forward request", "Wait for owner", "Manual report"],
    after: ["Guided request", "Knowledge search", "Smart routing", "Human resolution", "Central insight"],
  },
]

const workflow = [
  ["01", "Customer enquiry", "A customer submits a form, message, or request."],
  ["02", "Data capture", "Required information enters an agreed workflow."],
  ["03", "Validation", "Rules check format, consent, and required fields."],
  ["04", "AI or rules", "Suitable tasks are classified, assisted, or routed."],
  ["05", "CRM / database", "Validated data is stored in the right system."],
  ["06", "Automated action", "The workflow sends an alert, update, or task."],
  ["07", "Human review", "Your team reviews results and monitors reporting."],
]

const industries = [
  ["MF", "Manufacturing", "Product catalogues, quotation workflows, CRM, and reporting."],
  ["EN", "Engineering & fabrication", "Capability websites, enquiry routing, and project dashboards."],
  ["WD", "Wholesale & distribution", "Catalogues, inventory links, order tracking, and portals."],
  ["RE", "Retail & e-commerce", "Online stores, campaign landing pages, and customer journeys."],
  ["HC", "Healthcare & clinics", "Appointment enquiries and admin flows with suitable privacy safeguards."],
  ["ED", "Education & training", "Course websites, admission enquiries, and student system integrations."],
  ["RS", "Real estate", "Property presentation, lead capture, and sales follow-up workflows."],
  ["PS", "Professional services", "Lead generation, booking, and automated follow-up."],
  ["LG", "Logistics & supply chain", "Customer portals, status workflows, and operational reporting."],
  ["SB", "Startups & small business", "Scalable foundations matched to current needs and budgets."],
]

const process = [
  ["01", "Discover", "Understand your audience, challenges, systems, and objectives."],
  ["02", "Strategize", "Define the scope, success criteria, technical requirements, and deliverables."],
  ["03", "Design", "Prepare user journeys, wireframes, and visual direction."],
  ["04", "Build", "Implement the website, application, integration, or automation."],
  ["05", "Validate", "Test usability, performance, functionality, security, and data handling."],
  ["06", "Launch", "Deploy the agreed solution and configure required integrations."],
  ["07", "Improve", "Provide agreed monitoring, maintenance, analytics, and enhancements."],
]

const projects = [
  {
    category: "Website · Demonstration",
    title: "Industrial product enquiry platform",
    copy: "A demonstration of technical product discovery, specification downloads, and quotation routing.",
    tags: ["React", "Structured content", "CRM workflow"],
    className: "project-blue",
  },
  {
    category: "Automation · Demonstration",
    title: "Lead qualification workflow",
    copy: "An illustrative form-to-CRM flow with validation, assignment, notifications, and review.",
    tags: ["Business rules", "API integration", "Reporting"],
    className: "project-navy",
  },
  {
    category: "Dashboard · Demonstration",
    title: "Operations intelligence dashboard",
    copy: "A sample interface for monitoring sales, service requests, tasks, and operational KPIs.",
    tags: ["Power BI", "Data modelling", "KPI design"],
    className: "project-cyan",
  },
]

const packages = [
  {
    name: "Starter Website",
    price: "₹6,500",
    copy: "A focused foundation for a small business.",
    features: ["Up to 5 pages", "Responsive layout", "Basic contact form", "Basic on-page SEO setup"],
  },
  {
    name: "Business Website",
    price: "₹15,000",
    copy: "A professional site designed for enquiry growth.",
    features: ["Up to 12 pages", "Professional responsive design", "Enquiry forms", "WhatsApp integration", "On-page SEO foundations"],
    featured: true,
  },
  {
    name: "Dynamic Website",
    price: "₹20,000",
    copy: "Flexible content and agreed management tools.",
    features: ["Up to 20 pages", "Dynamic content by scope", "Admin or CMS where included", "Enquiry management", "On-page SEO foundations"],
  },
]

const articles = [
  ["AI & automation", "A practical guide to AI automation for small businesses", "Where AI can help, what data it needs, and when a simpler workflow is better."],
  ["Website development", "What a business website needs before it can generate enquiries", "A clear checklist covering trust, user journeys, performance, and measurement."],
  ["Business intelligence", "Planning a useful Power BI dashboard", "How to choose KPIs, prepare data, and avoid reporting that creates more noise."],
]

function Icon({ name }: { name: IconName }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    automation: <><path d="M12 3v3m0 12v3M3 12h3m12 0h3" /><circle cx="12" cy="12" r="4" /><path d="m5.6 5.6 2.1 2.1m8.6 8.6 2.1 2.1m0-12.8-2.1 2.1M7.7 16.3l-2.1 2.1" /></>,
    chart: <><path d="M4 20V10m6 10V4m6 16v-7m4 7H2" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    cloud: <path d="M7 18h10a4 4 0 0 0 .6-8A6 6 0 0 0 6.2 8.5 4.8 4.8 0 0 0 7 18Z" />,
    code: <><path d="m8 8-4 4 4 4m8-8 4 4-4 4M14 5l-4 14" /></>,
    commerce: <><path d="M3 5h2l2 10h10l2-7H6" /><circle cx="9" cy="19" r="1" /><circle cx="17" cy="19" r="1" /></>,
    data: <><ellipse cx="12" cy="5" rx="7" ry="3" /><path d="M5 5v7c0 1.7 3.1 3 7 3s7-1.3 7-3V5M5 12v7c0 1.7 3.1 3 7 3s7-1.3 7-3v-7" /></>,
    design: <><path d="m4 20 5-1 10-10-4-4L5 15l-1 5Z" /><path d="m13 7 4 4" /></>,
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    mobile: <><rect x="7" y="2" width="10" height="20" rx="2" /><path d="M10 5h4m-3 14h2" /></>,
    search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 5 5" /></>,
    spark: <><path d="m12 2 1.5 5.5L19 9l-5.5 1.5L12 16l-1.5-5.5L5 9l5.5-1.5L12 2Z" /><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z" /></>,
    web: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18" /></>,
    whatsapp: <><path d="M20 11.6a8 8 0 0 1-11.8 7L4 20l1.4-4A8 8 0 1 1 20 11.6Z" /><path d="M8.5 8.5c.5 3 2 4.5 5 5" /></>,
    x: <path d="m6 6 12 12M18 6 6 18" />,
  }
  return <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

function Logo({ light = false }: { light?: boolean }) {
  return (
    <span className={`logo-lockup ${light ? "logo-light" : ""}`}>
      <span className="ak-mark" aria-hidden="true"><i>A</i><i>X</i></span>
      <span className="logo-copy"><strong>AK Innovexa</strong><small>Ideas engineered into solutions</small></span>
    </span>
  )
}

function ButtonLink({ href, children, secondary = false, className = "" }: { href: string; children: ReactNode; secondary?: boolean; className?: string }) {
  return <a className={`button ${secondary ? "button-secondary" : ""} ${className}`} href={href}>{children}<Icon name="arrow" /></a>
}

function Heading({ eyebrow, title, copy, align = "left", light = false }: { eyebrow: string; title: string; copy?: string; align?: "left" | "center"; light?: boolean }) {
  return <div className={`section-heading heading-${align} ${light ? "heading-light" : ""}`}><span className="eyebrow">{eyebrow}</span><h2>{title}</h2>{copy && <p>{copy}</p>}</div>
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [activeFlow, setActiveFlow] = useState(0)
  const [activeEcosystem, setActiveEcosystem] = useState(0)
  const [activeLab, setActiveLab] = useState(0)
  const [activeTransformation, setActiveTransformation] = useState(0)
  const [activeFaq, setActiveFaq] = useState<number | null>(0)
  const [formMessage, setFormMessage] = useState("")

  const closeMenu = () => setMenuOpen(false)

  function submitInquiry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    if (!form.get("consent")) {
      setFormMessage("Please confirm that we may respond to your enquiry.")
      return
    }
    const message = [
      "Hello AK Innovexa, I would like to discuss a project.",
      `Name: ${form.get("name")}`,
      `Business: ${form.get("business")}`,
      `Phone: ${form.get("phone")}`,
      `Email: ${form.get("email")}`,
      `Country: ${form.get("country")}`,
      `Service: ${form.get("service")}`,
      `Budget: ${form.get("budget")}`,
      `Timeframe: ${form.get("timeframe")}`,
      `Preferred contact: ${form.get("preference")}`,
      `Details: ${form.get("details")}`,
    ].join("\n")
    setFormMessage("Opening WhatsApp with your enquiry. Review the message before sending.")
    window.open(`https://wa.me/${PHONE}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer")
  }

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main">Skip to content</a>
      <header className="site-header">
        <div className="header-inner">
          <a href="#top" aria-label="AK Innovexa home" onClick={closeMenu}><Logo /></a>
          <nav className={menuOpen ? "nav nav-open" : "nav"} aria-label="Main navigation">
            {[
              ["Ecosystem", "#ecosystem"], ["Services", "#services"], ["AI Lab", "#ai-lab"],
              ["Industries", "#industries"], ["Work", "#portfolio"], ["Process", "#process"], ["Insights", "#blog"],
            ].map(([label, href]) => <a key={href} href={href} onClick={closeMenu}>{label}</a>)}
          </nav>
          <div className="header-actions">
            <a className="whatsapp-button" href={`https://wa.me/${PHONE}`} target="_blank" rel="noreferrer" aria-label="Chat with AK Innovexa on WhatsApp"><Icon name="whatsapp" /></a>
            <ButtonLink href="#contact" className="header-cta">Free consultation</ButtonLink>
            <button className="menu-button" type="button" aria-label="Toggle navigation" aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)}><Icon name={menuOpen ? "x" : "menu"} /></button>
          </div>
        </div>
      </header>

      <main id="main">
        <section className="hero" id="top">
          <div className="hero-orb hero-orb-one" /><div className="hero-orb hero-orb-two" />
          <div className="shell hero-grid">
            <div className="hero-copy">
              <span className="eyebrow"><i /> Ideas engineered into solutions</span>
              <h1>Turn Your Business Vision Into <span>Intelligent Digital Solutions.</span></h1>
              <p>AK Innovexa helps businesses build powerful digital experiences, automate repetitive processes, connect customer systems, and make smarter decisions through software, AI, and data-driven solutions.</p>
              <div className="hero-actions">
                <ButtonLink href="#contact">Book a free consultation</ButtonLink>
                <ButtonLink href="#services" secondary>Explore our solutions</ButtonLink>
                <a className="hero-text-link" href="#portfolio">View our work <Icon name="arrow" /></a>
              </div>
              <div className="hero-trust">
                <span>Practical technology</span><span>Transparent scope</span><span>Responsive support</span>
              </div>
            </div>
            <div className="hero-visual" aria-label="Illustrative business automation dashboard">
              <div className="dashboard-window">
                <div className="window-top"><span /><span /><span /><b>INNOVEXA / CONNECTED BUSINESS HUB</b></div>
                <div className="dashboard-body">
                  <aside><Logo light /><i className="active" /><i /><i /><i /></aside>
                  <div className="dashboard-main">
                    <div className="dash-heading"><div><small>Workspace overview</small><strong>Good morning, team</strong></div><span>Live workflow</span></div>
                    <div className="metric-row">
                      <div><small>New enquiries</small><strong>24</strong><em>Ready for review</em></div>
                      <div><small>Open tasks</small><strong>08</strong><em>Across 3 workflows</em></div>
                      <div><small>Response status</small><strong>On track</strong><em>Updated today</em></div>
                    </div>
                    <div className="dash-grid">
                      <div className="chart-card"><span>Enquiry activity</span><div className="bars">{[38,55,43,72,61,88,74,91,68,83,96,87].map((height, index) => <i key={index} style={{height: `${height}%`}} />)}</div><div className="chart-line"><i /><i /><i /><i /><i /></div></div>
                      <div className="flow-card"><span>Automation flow</span><div><i className="done"><Icon name="check" /></i><p><b>Website enquiry</b><small>Captured & validated</small></p></div><div><i className="active"><Icon name="automation" /></i><p><b>Lead assignment</b><small>Business rules running</small></p></div><div><i><Icon name="data" /></i><p><b>CRM update</b><small>Next action queued</small></p></div></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="floating-pill pill-one"><Icon name="spark" /><span><small>AI solutions</small>Knowledge assistant</span></div>
              <div className="floating-pill pill-two"><Icon name="automation" /><span><small>Smart automation</small>Workflow connected</span></div>
              <div className="floating-pill pill-three"><Icon name="chart" /><span><small>Digital growth</small>Insights that help</span></div>
            </div>
          </div>
          <div className="solution-strip"><div className="shell">{["Website development", "Custom software", "AI solutions", "Business automation", "Digital marketing", "Data analytics"].map((item) => <span key={item}><i />{item}</span>)}</div></div>
        </section>

        <section className="section about" id="about">
          <div className="shell about-grid">
            <div>
              <Heading eyebrow="About AK Innovexa" title="Technology engineered around business possibility" />
              <p className="lead-copy">We combine website development, custom software, AI-powered tools, workflow automation, and digital marketing to create practical solutions around real business needs.</p>
              <p>Our approach focuses on understanding your goals, selecting the right technology, building reliable systems, and providing ongoing support as your business evolves.</p>
              <ButtonLink href="#process" secondary>See how we work</ButtonLink>
            </div>
            <div className="strategy-visual">
              <div className="strategy-center"><span>AK</span><strong>Business growth</strong></div>
              {[
                ["01", "Strategy", "Clear priorities"], ["02", "Software", "Reliable systems"],
                ["03", "AI", "Useful intelligence"], ["04", "Growth", "Better journeys"],
              ].map(([number, title, copy]) => <div className={`strategy-node node-${number}`} key={number}><small>{number}</small><strong>{title}</strong><span>{copy}</span></div>)}
              <svg viewBox="0 0 500 400" aria-hidden="true"><path d="M105 95 250 200 395 95M105 305 250 200l145 105" /></svg>
            </div>
          </div>
          <div className="shell values-grid">
            {[
              ["Our mission", "Make modern technology practical and valuable for growing businesses."],
              ["Our vision", "Help ambitious teams build stronger digital foundations for long-term progress."],
              ["Our approach", "Understand first, choose the simplest suitable stack, and communicate clearly."],
              ["Why choose us", "Thoughtful solutions, transparent scope, scalable architecture, and responsive support."],
            ].map(([title, text], index) => <article key={title}><span>0{index + 1}</span><h3>{title}</h3><p>{text}</p></article>)}
          </div>
        </section>

        <section className="section ecosystem" id="ecosystem">
          <div className="shell">
            <Heading eyebrow="The Innovexa digital ecosystem" title="One connected ecosystem. Multiple business possibilities." copy="Explore how customer-facing experiences, operational tools, communication, intelligence, and growth systems can work together around one business journey." align="center" />
            <div className="ecosystem-layout">
              <div className="ecosystem-map" aria-label="Interactive digital ecosystem">
                <div className="ecosystem-core"><span>AX</span><strong>Connected<br />business</strong></div>
                <svg viewBox="0 0 600 600" aria-hidden="true">
                  <circle cx="300" cy="300" r="205" />
                  {[[300,62],[468,132],[538,300],[468,468],[300,538],[132,468],[62,300],[132,132]].map(([x,y], index) => <line key={index} x1="300" y1="300" x2={x} y2={y} />)}
                </svg>
                {ecosystemNodes.map((node, index) => <button className={`ecosystem-node ecosystem-node-${index + 1} ${activeEcosystem === index ? "active" : ""}`} type="button" key={node.title} onClick={() => setActiveEcosystem(index)} aria-pressed={activeEcosystem === index}><Icon name={node.icon} /><span>{node.title}</span></button>)}
              </div>
              <div className="ecosystem-detail" aria-live="polite">
                <span className="mono-label">SYSTEM / {String(activeEcosystem + 1).padStart(2, "0")}</span>
                <div className="ecosystem-detail-icon"><Icon name={ecosystemNodes[activeEcosystem].icon} /></div>
                <h3>{ecosystemNodes[activeEcosystem].title}</h3>
                <p>{ecosystemNodes[activeEcosystem].problem}</p>
                <dl><div><dt>Connects with</dt><dd>{ecosystemNodes[activeEcosystem].connects}</dd></div><div><dt>Example deliverables</dt><dd>{ecosystemNodes[activeEcosystem].deliverables}</dd></div></dl>
                <ButtonLink href="#contact">Plan this system</ButtonLink>
              </div>
            </div>
          </div>
        </section>

        <section className="section services" id="services">
          <div className="shell">
            <Heading eyebrow="What we do" title="Digital capability, built around your business" copy="Choose a focused service or combine capabilities into a custom project. Every advanced solution is scoped around your requirements, systems, data, and budget." />
            <div className="services-grid">
              {serviceGroups.map((service) => <article className="service-card" key={service.title}>
                <div className="service-icon"><Icon name={service.icon} /></div>
                <h3>{service.title}</h3><p>{service.description}</p>
                <ul>{service.deliverables.map((item) => <li key={item}><Icon name="check" />{item}</li>)}</ul>
                <div className="use-case"><small>Best suited for</small><span>{service.useCase}</span></div>
                <div className="card-actions"><a href="#contact">Learn more <Icon name="arrow" /></a><a href="#contact">Request a quote</a></div>
              </article>)}
            </div>
            <div className="integration-note"><div><span className="mono-label">COMMUNICATION INTEGRATIONS</span><h3>Official platform, provider, or custom solution?</h3></div><p>WhatsApp, SMS, RCS, voice, email, OTP, and AI features rely on approved platform APIs or supported third-party providers. AK Innovexa designs and connects the business workflow; provider approval, templates, message fees, service availability, and account compliance remain separate. Custom software does not bypass official platform requirements.</p><ButtonLink href="#contact" secondary>Discuss an integration</ButtonLink></div>
          </div>
        </section>

        <section className="section automation" id="automation">
          <div className="shell">
            <Heading eyebrow="AI & automation" title="Make your business smarter with connected workflows" copy="Reduce repetitive work, improve visibility, and give your team better tools without automating decisions that still need human judgement." light />
            <div className="automation-grid">
              <div className="automation-cases">
                {automationCases.map(([title, copy], index) => <article key={title}><span><Icon name={index === 0 ? "spark" : index === 2 ? "search" : index === 3 ? "chart" : index === 4 ? "whatsapp" : "automation"} /></span><div><h3>{title}</h3><p>{copy}</p></div></article>)}
              </div>
              <div className="workflow-panel">
                <div className="workflow-top"><span>Interactive workflow</span><small>Click a step to explore</small></div>
                <div className="workflow-list">
                  {workflow.map(([number, title], index) => <button className={activeFlow === index ? "active" : ""} key={number} type="button" onClick={() => setActiveFlow(index)}><span>{number}</span><b>{title}</b><i /></button>)}
                </div>
                <div className="workflow-detail"><span>{workflow[activeFlow][0]}</span><div><strong>{workflow[activeFlow][1]}</strong><p>{workflow[activeFlow][2]}</p></div></div>
                <p className="workflow-note">AI output may require human verification. Feasibility depends on available data, permissions, integrations, and business requirements.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="section ai-lab" id="ai-lab">
          <div className="shell">
            <div className="section-row"><Heading eyebrow="Innovexa AI Lab" title="Explore ideas before building the production system" copy="Interactive previews make complex capabilities easier to understand. Every example below is clearly labelled and runs without private data or live third-party APIs." /><span className="lab-status"><i /> Preview environment</span></div>
            <div className="lab-layout">
              <div className="lab-tabs" role="tablist" aria-label="AI Lab demonstrations">
                {labDemos.map((demo, index) => <button role="tab" aria-selected={activeLab === index} className={activeLab === index ? "active" : ""} key={demo.title} type="button" onClick={() => setActiveLab(index)}><span><Icon name={demo.icon} /></span><div><small>Demo {String(index + 1).padStart(2, "0")}</small><strong>{demo.title}</strong></div><Icon name="arrow" /></button>)}
              </div>
              <div className="lab-console" role="tabpanel">
                <div className="console-top"><span /><span /><span /><b>PREVIEW_MODE / NO LIVE API</b></div>
                <div className="console-body">
                  <span className="mono-label">INTERACTIVE CONCEPT</span>
                  <h3>{labDemos[activeLab].title}</h3>
                  <p>{labDemos[activeLab].preview}</p>
                  <div className="console-output">{labDemos[activeLab].output.map((item, index) => <div key={item}><span>{String(index + 1).padStart(2, "0")}</span><i /><strong>{item}</strong></div>)}</div>
                  <div className="console-limit"><Icon name="check" /><p><strong>What this preview does not do</strong>{labDemos[activeLab].limitation}</p></div>
                  <ButtonLink href="#contact" secondary>Request a custom version</ButtonLink>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="visual-story">
          <div className="shell visual-story-grid">
            <div className="story-image story-image-large"><img src="https://images.unsplash.com/flagged/photo-1576485436509-a7d286952b65?auto=format&fit=crop&w=1200&q=82" alt="Business team collaborating around a table in a modern workspace" loading="lazy" /><span>Strategy meets engineering</span></div>
            <div className="story-copy"><span className="eyebrow">Built for real operating environments</span><h2>From the boardroom to the factory floor.</h2><p>We shape technology around the people who use it—whether they manage customers, production, inventory, communications, campaigns, or business reporting.</p><div><span>India-based delivery</span><span>Global-ready communication</span><span>Industry-aware solutions</span></div></div>
            <div className="story-image story-image-small"><img src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=900&q=82" alt="Engineer using a laptop beside industrial equipment" loading="lazy" /><span>Technology in context</span></div>
          </div>
        </section>

        <section className="section industries" id="industries">
          <div className="shell">
            <Heading eyebrow="Industries we serve" title="Technology that adapts to how your sector works" copy="We begin with relevant use cases, not generic promises. The final solution is shaped around your processes, customers, and compliance needs." />
            <div className="industry-grid">{industries.map(([code, title, copy]) => <article key={code}><span>{code}</span><h3>{title}</h3><p>{copy}</p><a href="#contact" aria-label={`Discuss a ${title} project`}><Icon name="arrow" /></a></article>)}</div>
          </div>
        </section>

        <section className="section transformation" id="transformation">
          <div className="shell">
            <Heading eyebrow="From manual work to smart work" title="See how a connected workflow changes the experience" copy="Choose a common process to compare disconnected handoffs with a validated, visible workflow. These examples illustrate possibilities—not guaranteed time or revenue outcomes." />
            <div className="transformation-tabs">{transformations.map((item, index) => <button type="button" className={activeTransformation === index ? "active" : ""} key={item.title} onClick={() => setActiveTransformation(index)}>{item.title}</button>)}</div>
            <div className="transformation-board">
              <div className="flow-column before"><span>Before / disconnected</span>{transformations[activeTransformation].before.map((step, index) => <div key={step}><i>{String(index + 1).padStart(2, "0")}</i><strong>{step}</strong>{index < 4 && <Icon name="arrow" />}</div>)}</div>
              <div className="transform-center"><span><Icon name="automation" /></span><strong>Connect<br />Validate<br />Improve</strong></div>
              <div className="flow-column after"><span>After / connected</span>{transformations[activeTransformation].after.map((step, index) => <div key={step}><i>{String(index + 1).padStart(2, "0")}</i><strong>{step}</strong>{index < 4 && <Icon name="arrow" />}</div>)}</div>
            </div>
          </div>
        </section>

        <section className="section process-section" id="process">
          <div className="shell">
            <div className="section-row"><Heading eyebrow="Our process" title="From an idea to a dependable solution" /><ButtonLink href="#contact" secondary>Discuss your project</ButtonLink></div>
            <div className="process-line">{process.map(([number, title, copy]) => <article key={number}><span>{number}</span><h3>{title}</h3><p>{copy}</p></article>)}</div>
          </div>
        </section>

        <section className="section portfolio" id="portfolio">
          <div className="shell">
            <Heading eyebrow="Selected solution concepts" title="See how strategy becomes a working experience" copy="The examples below are clearly labelled demonstrations of our approach—not fabricated client work or claimed outcomes." light />
            <div className="project-grid">{projects.map((project) => <article className={project.className} key={project.title}><div className="project-preview"><div className="preview-nav" /><div className="preview-side" /><div className="preview-chart"><i /><i /><i /><i /><i /></div><div className="preview-cards"><i /><i /><i /></div></div><span>{project.category}</span><h3>{project.title}</h3><p>{project.copy}</p><div className="project-tags">{project.tags.map((tag) => <i key={tag}>{tag}</i>)}</div><a href="#contact">Discuss a similar project <Icon name="arrow" /></a></article>)}</div>
          </div>
        </section>

        <section className="section pricing" id="pricing">
          <div className="shell">
            <Heading eyebrow="Indicative website packages" title="A clear starting point, with room to tailor" copy="These are starting packages for common website scopes. We confirm requirements, deliverables, timeline, and exclusions before work begins." align="center" />
            <div className="pricing-grid">{packages.map((item) => <article className={item.featured ? "featured" : ""} key={item.name}>{item.featured && <span className="popular">Popular starting point</span>}<h3>{item.name}</h3><p>{item.copy}</p><div className="price"><small>Starting from</small><strong>{item.price}</strong></div><ul>{item.features.map((feature) => <li key={feature}><Icon name="check" />{feature}</li>)}</ul><ButtonLink href="#contact" secondary>Request this package</ButtonLink></article>)}</div>
            <p className="price-note">Advanced AI, custom applications, paid APIs, premium plugins, extensive content, and third-party subscriptions require separate scoping. Domain, hosting, business email, licences, and maintenance are not included unless confirmed in writing.</p>
            <div className="engagement-models">{[["Fixed scope", "Suitable when requirements and deliverables can be defined clearly before work begins."],["Milestone based", "Useful for larger builds delivered and reviewed through agreed project stages."],["Monthly engagement", "For ongoing marketing, optimization, support, or an evolving product roadmap."]].map(([title, copy]) => <article key={title}><span><Icon name="check" /></span><div><h3>{title}</h3><p>{copy}</p></div></article>)}</div>
            <div className="pricing-cta"><div><span>Need software, automation, e-commerce, or an AI solution?</span><strong>Tell us what the business needs to achieve.</strong></div><ButtonLink href="#contact">Request a custom quote</ButtonLink></div>
            <div className="faq-grid">
              <Heading eyebrow="Pricing FAQ" title="Questions before we begin" />
              <div className="faq-list">{[
                ["Are these final fixed prices?", "No. They are indicative starting packages. Your written proposal will confirm the final scope and price."],
                ["What do you need to provide a quote?", "Your goals, required features, available content, integrations, timeline, and any current systems are a helpful start."],
                ["Can the website grow later?", "Yes. We plan the architecture around agreed future needs while avoiding unnecessary complexity today."],
                ["Do you provide ongoing support?", "Support and maintenance can be scoped separately based on the level of monitoring and response your system needs."],
              ].map(([question, answer], index) => <article className={activeFaq === index ? "open" : ""} key={question}><button type="button" onClick={() => setActiveFaq(activeFaq === index ? null : index)} aria-expanded={activeFaq === index}><span>{question}</span><i>{activeFaq === index ? "−" : "+"}</i></button><div><p>{answer}</p></div></article>)}</div>
            </div>
          </div>
        </section>

        <section className="tech-band">
          <div className="shell tech-grid"><div><span>Technology approach</span><h2>The simplest reliable stack for the job</h2><p>We select tools according to scope rather than forcing every project into the same architecture.</p></div><div>{["React & TypeScript", "Node.js & APIs", "Python & FastAPI", "PostgreSQL", "Power BI & SQL", "Cloud deployment"].map((tech) => <span key={tech}>{tech}</span>)}</div></div>
        </section>

        <section className="section insights" id="blog">
          <div className="shell">
            <div className="section-row"><Heading eyebrow="Knowledge centre" title="Useful ideas for smarter digital decisions" /><a className="plain-link" href="#contact">Suggest a topic <Icon name="arrow" /></a></div>
            <div className="article-grid">{articles.map(([category, title, copy], index) => <article key={title}><div className={`article-image article-image-${index + 1}`}><span>AK<span>/{String(index + 1).padStart(2, "0")}</span></span></div><small>{category} · 6 min read</small><h3>{title}</h3><p>{copy}</p><a href="#contact">Request the guide <Icon name="arrow" /></a></article>)}</div>
          </div>
        </section>

        <section className="section contact" id="contact">
          <div className="shell contact-grid">
            <div className="contact-copy">
              <span className="eyebrow eyebrow-light">Start a conversation</span><h2>Let’s build the right next step for your business.</h2>
              <p>Share your goals and current challenge. We’ll use the information only to understand your enquiry and prepare for a practical conversation.</p>
              <div className="contact-methods"><a href={`tel:+${PHONE}`}><span>Call us</span><strong>+91 78742 26912</strong></a><a href={`mailto:${EMAIL}`}><span>Email us</span><strong>{EMAIL}</strong></a><a href={`https://wa.me/${PHONE}`} target="_blank" rel="noreferrer"><span>WhatsApp</span><strong>Start a chat <Icon name="arrow" /></strong></a></div>
              <small>Ahmedabad, Gujarat, India · Supporting projects in India and international markets</small>
            </div>
            <form className="contact-form" onSubmit={submitInquiry}>
              <div className="form-heading"><span>Free initial consultation</span><h3>Tell us about your project</h3></div>
              <div className="field-row"><label><span>Your name *</span><input name="name" required autoComplete="name" /></label><label><span>Business name *</span><input name="business" required autoComplete="organization" /></label></div>
              <div className="field-row"><label><span>Phone with country code *</span><input name="phone" required type="tel" autoComplete="tel" placeholder="+91" /></label><label><span>Business email *</span><input name="email" required type="email" autoComplete="email" /></label></div>
              <div className="field-row"><label><span>Country *</span><select name="country" required defaultValue=""><option value="" disabled>Select country or region</option><option>India</option><option>United Arab Emirates</option><option>United Kingdom</option><option>United States</option><option>Canada</option><option>Australia</option><option>Other international market</option></select></label><label><span>Desired timeframe *</span><select name="timeframe" required defaultValue=""><option value="" disabled>Select timeframe</option><option>Within 1 month</option><option>1–3 months</option><option>3–6 months</option><option>Exploring options</option></select></label></div>
              <div className="field-row"><label><span>Service required *</span><select name="service" required defaultValue=""><option value="" disabled>Select a service</option>{serviceGroups.map((service) => <option key={service.title}>{service.title}</option>)}<option>Not sure yet</option></select></label><label><span>Approximate budget *</span><select name="budget" required defaultValue=""><option value="" disabled>Select a range</option><option>Below ₹15,000</option><option>₹15,000 – ₹50,000</option><option>₹50,000 – ₹2,00,000</option><option>Above ₹2,00,000</option><option>Need guidance</option></select></label></div>
              <label><span>Project details *</span><textarea name="details" required rows={4} placeholder="What do you want to build or improve?" /></label>
              <div className="preference"><span>Preferred contact *</span><label><input type="radio" name="preference" value="WhatsApp" required />WhatsApp</label><label><input type="radio" name="preference" value="Phone" />Phone</label><label><input type="radio" name="preference" value="Email" />Email</label></div>
              <label className="consent"><input type="checkbox" name="consent" required /><span>I consent to AK Innovexa using these details to respond to my enquiry. My message will open in WhatsApp for my review before I send it.</span></label>
              <button className="button form-submit" type="submit">Continue to WhatsApp <Icon name="whatsapp" /></button>
              {formMessage && <p className="form-message" role="status">{formMessage}</p>}
            </form>
          </div>
        </section>
      </main>

      <footer>
        <div className="shell footer-grid">
          <div className="footer-brand"><a href="#top"><Logo light /></a><p>AI, software development, business automation, and digital growth solutions built around real business needs.</p><a className="footer-phone" href={`tel:+${PHONE}`}>+91 78742 26912</a></div>
          <div><span>Solutions</span>{["Web development", "Custom software", "AI & automation", "Digital marketing", "Data analytics"].map((item) => <a key={item} href="#services">{item}</a>)}</div>
          <div><span>Company</span><a href="#about">About us</a><a href="#process">Our process</a><a href="#portfolio">Portfolio</a><a href="#pricing">Pricing</a><a href="#blog">Knowledge centre</a></div>
          <div><span>Industries</span><a href="#industries">Manufacturing</a><a href="#industries">Retail & e-commerce</a><a href="#industries">Professional services</a><a href="#industries">Startups & small business</a><a href="#contact">Contact us</a></div>
        </div>
        <div className="shell footer-bottom"><span>© {new Date().getFullYear()} AK Innovexa. All rights reserved.</span><div><a href="#contact">Privacy</a><a href="#contact">Terms</a><span>Ahmedabad, Gujarat, India</span></div></div>
      </footer>
      <a className="floating-whatsapp" href={`https://wa.me/${PHONE}?text=${encodeURIComponent("Hello AK Innovexa, I would like to discuss a project.")}`} target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"><Icon name="whatsapp" /></a>
    </div>
  )
}

export default App
